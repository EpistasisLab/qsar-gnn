Assays:

- `tox21-pxr-p1` (index 29)
- `tox21-rt-viability-hepg2-p2` (index 45)

Column headers:
assay_index	node_id	acc	f1	pos_ratio


`tox21-pxr-p1`
- Remove MACCS; replace with single dummy feature (29_no_maccs.tsv)
29      1548    0.8966  0.7722  0.247

- Remove assay nodes (29_no_assays.tsv)
29      1548    0.7492  0.0896  0.247

- Remove gene nodes (29_no_genes.tsv)
29      1548    0.9074  0.8165  0.247


`tox21-rt-viability-hepg2-p2`
- Remove MACCS; replace with single dummy feature (45_no_maccs.tsv)
45      2615    0.8814  0.5070  0.150

- Remove assay nodes (45_no_assays.tsv)
45      2615    0.8506  0.1116  0.150

- Remove gene nodes (45_no_genes.tsv)
45      2615    0.8841  0.4836  0.150